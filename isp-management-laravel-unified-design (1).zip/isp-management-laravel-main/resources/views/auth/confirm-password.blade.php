{{-- resources/views/auth/confirm-password.blade.php --}}
@extends('layouts.auth')

@section('auth_title', 'Confirm Password')
@section('auth_subtitle', 'Secure area verification')

@section('auth_content')
    <form method="POST" action="{{ route('password.confirm') }}">
        @csrf

        <div class="form-group">
            <label for="password">{{ __('Password') }}</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="{{ __('Confirm your password to continue') }}"
                    required autocomplete="current-password" autofocus>
            </div>
            @error('password')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-shield-alt" style="margin-right:6px;"></i> {{ __('Confirm') }}
        </button>
    </form>
@endsection

@section('auth_note')
    <div class="hint-box">
        <strong><i class="fas fa-info-circle"></i> {{ __('Info') }}</strong>
        {{ __('This is a secure area of the application. Please confirm your password before continuing.') }}
    </div>
@endsection
