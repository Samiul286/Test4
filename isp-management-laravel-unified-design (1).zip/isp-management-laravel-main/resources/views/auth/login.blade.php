{{-- resources/views/auth/login.blade.php --}}
@extends('layouts.auth')

@section('auth_title', 'Login')
@section('auth_subtitle', 'Admin & Staff Portal')

@section('auth_content')
    <form method="POST" action="{{ route('login') }}">
        @csrf

        <div class="form-group">
            <label for="email">{{ __('Email Address') }}</label>
            <div class="input-wrap">
                <i class="fas fa-envelope"></i>
                <input type="email" id="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    placeholder="{{ __('Your email address') }}"
                    value="{{ old('email') }}"
                    autocomplete="username" required autofocus>
            </div>
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="password">{{ __('Password') }}</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="{{ __('Your password') }}"
                    autocomplete="current-password" required>
            </div>
            @error('password')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="remember-row">
            <input type="checkbox" name="remember" id="remember" value="1">
            <label for="remember">{{ __('Remember me') }}</label>
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-sign-in-alt" style="margin-right:6px;"></i> {{ __('Login') }}
        </button>
    </form>
@endsection

@section('auth_links')
    @if (Route::has('password.request'))
        <a href="{{ route('password.request') }}">{{ __('Forgot your password?') }}</a>
    @endif
@endsection
