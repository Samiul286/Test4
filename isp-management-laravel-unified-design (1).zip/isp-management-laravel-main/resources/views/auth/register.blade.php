{{-- resources/views/auth/register.blade.php --}}
@extends('layouts.auth')

@section('auth_title', 'Register')
@section('auth_subtitle', 'Create a new account')

@section('auth_content')
    <form method="POST" action="{{ route('register') }}">
        @csrf

        <div class="form-group">
            <label for="name">{{ __('Full Name') }}</label>
            <div class="input-wrap">
                <i class="fas fa-user"></i>
                <input type="text" id="name" name="name"
                    class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}"
                    placeholder="{{ __('Your full name') }}"
                    value="{{ old('name') }}" required autofocus autocomplete="name">
            </div>
            @error('name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="email">{{ __('Email Address') }}</label>
            <div class="input-wrap">
                <i class="fas fa-envelope"></i>
                <input type="email" id="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    placeholder="{{ __('Your email address') }}"
                    value="{{ old('email') }}" required autocomplete="email">
            </div>
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="password">{{ __('Password') }}</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="{{ __('Choose a strong password') }}"
                    required autocomplete="new-password">
            </div>
            @error('password')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="password_confirmation">{{ __('Confirm Password') }}</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" id="password_confirmation" name="password_confirmation"
                    class="form-control"
                    placeholder="{{ __('Repeat your password') }}"
                    required autocomplete="new-password">
            </div>
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-user-plus" style="margin-right:6px;"></i> {{ __('Register') }}
        </button>
    </form>
@endsection

@section('auth_links')
    <a href="{{ route('login') }}">{{ __('Already have an account? Login') }}</a>
@endsection
