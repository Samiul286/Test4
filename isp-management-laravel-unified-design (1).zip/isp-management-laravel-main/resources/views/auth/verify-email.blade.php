{{-- resources/views/auth/verify-email.blade.php --}}
@extends('layouts.auth')

@section('auth_title', 'Verify Email')
@section('auth_subtitle', 'Email verification required')

@section('auth_content')
    <form method="POST" action="{{ route('verification.send') }}">
        @csrf

        <button type="submit" class="btn-login">
            <i class="fas fa-redo" style="margin-right:6px;"></i> {{ __('Resend Verification Email') }}
        </button>
    </form>

    <form method="POST" action="{{ route('logout') }}" style="margin-top:10px;">
        @csrf
        <button type="submit" class="btn-login" style="background:#95a5a6;">
            <i class="fas fa-sign-out-alt" style="margin-right:6px;"></i> {{ __('Log Out') }}
        </button>
    </form>
@endsection

@section('auth_note')
    <div class="hint-box">
        <strong><i class="fas fa-envelope-open-text"></i> {{ __('Verification pending') }}</strong>
        {{ __('Thanks for signing up! Before getting started, could you verify your email address by clicking on the link we just emailed to you? If you didn\'t receive the email, we will gladly send you another.') }}
    </div>
@endsection
