{{-- resources/views/auth/reset-password.blade.php --}}
@extends('layouts.auth')

@section('auth_title', 'Reset Password')
@section('auth_subtitle', 'Choose a new password')

@section('auth_content')
    <form method="POST" action="{{ route('password.store') }}">
        @csrf

        <input type="hidden" name="token" value="{{ $request->route('token') }}">

        <div class="form-group">
            <label for="email">{{ __('Email Address') }}</label>
            <div class="input-wrap">
                <i class="fas fa-envelope"></i>
                <input type="email" id="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    value="{{ old('email', $request->email) }}" required autofocus autocomplete="username">
            </div>
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="password">{{ __('New Password') }}</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    required autocomplete="new-password">
            </div>
            @error('password')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="password_confirmation">{{ __('Confirm New Password') }}</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" id="password_confirmation" name="password_confirmation"
                    class="form-control" required autocomplete="new-password">
            </div>
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-key" style="margin-right:6px;"></i> {{ __('Reset Password') }}
        </button>
    </form>
@endsection

@section('auth_links')
    <a href="{{ route('login') }}">{{ __('Back to login') }}</a>
@endsection
