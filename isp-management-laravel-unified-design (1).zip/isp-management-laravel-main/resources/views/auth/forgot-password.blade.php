{{-- resources/views/auth/forgot-password.blade.php --}}
@extends('layouts.auth')

@section('auth_title', 'Reset Password')
@section('auth_subtitle', 'Recover your account')

@section('auth_content')
    <form method="POST" action="{{ route('password.email') }}">
        @csrf

        <div class="form-group">
            <label for="email">{{ __('Email Address') }}</label>
            <div class="input-wrap">
                <i class="fas fa-envelope"></i>
                <input type="email" id="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    placeholder="{{ __('Your email address') }}"
                    value="{{ old('email') }}" required autofocus autocomplete="email">
            </div>
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-paper-plane" style="margin-right:6px;"></i> {{ __('Send Password Reset Link') }}
        </button>
    </form>
@endsection

@section('auth_links')
    <a href="{{ route('login') }}">{{ __('Back to login') }}</a>
@endsection
