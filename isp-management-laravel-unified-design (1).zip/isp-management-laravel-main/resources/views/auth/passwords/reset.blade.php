{{-- resources/views/auth/passwords/reset.blade.php (legacy alias) --}}
@extends('auth.reset-password')
