{{-- resources/views/auth/passwords/confirm.blade.php (legacy alias) --}}
@extends('auth.confirm-password')
