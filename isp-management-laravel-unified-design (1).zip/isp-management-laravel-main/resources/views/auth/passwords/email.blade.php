{{-- resources/views/auth/passwords/email.blade.php (legacy alias) --}}
@extends('auth.forgot-password')
