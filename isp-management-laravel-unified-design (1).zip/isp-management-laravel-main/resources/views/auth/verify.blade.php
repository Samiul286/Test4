{{-- resources/views/auth/verify.blade.php (legacy alias) --}}
@extends('auth.verify-email')
