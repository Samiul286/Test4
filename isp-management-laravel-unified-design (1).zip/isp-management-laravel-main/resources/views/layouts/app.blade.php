{{-- resources/views/layouts/app.blade.php --}}
@extends('adminlte::page')
@section('title', config('adminlte.title'))
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

{{-- ── Unified brand (topbar, left side) — Client-Portal design language ── --}}
@section('content_top_nav_left')
    <li class="nav-item">
        <a href="{{ route('dashboard') }}" class="portal-brand">
            <span class="portal-logo-box">{{ strtoupper(substr(\App\Models\Setting::get('company_name', 'S'), 0, 1)) }}</span>
            <span class="portal-brand-name">{{ \App\Models\Setting::get('company_name', 'SmartISP') }}</span>
        </a>
    </li>
@endsection

{{-- ── Notification Bell & language switcher — navbar right, before user menu ── --}}
@section('content_top_nav_right')
    @auth
        @include('partials.language-switcher')
        @include('partials.notification-bell')
    @endauth
    @parent
@stop

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1 class="m-0">@yield('page_title')</h1>
        <div>@yield('page_actions')</div>
    </div>
@stop

{{-- Footer also carries the global flash toast + shared modals (both are
     position:fixed / DOM-order independent, so they work regardless of
     whether the page overrides the "content" section or uses page_content). --}}
@section('footer')
    {{-- Global Toast Notification --}}
    @if(session('success') || session('error') || session('warning'))
    @php
        $type    = session('success') ? 'success' : (session('error') ? 'error' : 'warning');
        $message = session('success') ?? session('error') ?? session('warning');
        $color   = $type === 'success' ? '#00c897' : ($type === 'error' ? '#e74c3c' : '#f39c12');
        $icon    = $type === 'success' ? 'check-circle' : ($type === 'error' ? 'times-circle' : 'exclamation-triangle');
        $title   = $type === 'success' ? 'Success' : ($type === 'error' ? 'Error' : 'Warning');
    @endphp
    <div style="position:fixed; top:76px; right:20px; z-index:9999; min-width:320px; max-width:calc(100vw - 40px);">
        <div class="toast show" role="alert"
             style="border:none; border-radius:8px; box-shadow:0 8px 30px rgba(0,0,0,0.18); overflow:hidden;">
            <div class="toast-header" style="background:{{ $color }}; color:#fff; border:none;">
                <i class="fas fa-{{ $icon }} mr-2"></i>
                <strong class="mr-auto">{{ $title }}</strong>
                <button type="button" class="ml-2 close" data-dismiss="toast" style="color:#fff; opacity:1;">&times;</button>
            </div>
            <div class="toast-body" style="background:#fff; font-size:13px; padding:12px 16px;">
                {{ $message }}
            </div>
        </div>
    </div>
    @endif

    {{-- Quick Add Category Modal (shared for Income & Expense) --}}
    @include('accounting._quick_add_category_modal')

    {{ date('Y') }} &copy; {{ \App\Models\Setting::get('company_name', 'SmartISP') }}
@stop

@section('content')
    @yield('page_content')
@stop

{{-- Theme CSS is injected via adminlte_css (not the "css" section) so pages that
     define their own "css" section (inventory / bandwidth / settings modules)
     still keep the unified design system. --}}
@section('adminlte_css')
    <link rel="stylesheet" href="{{ asset('css/portal-theme.css') }}">
    <style>
    .swal2-title {
        font-size: 1.1rem !important;
        padding: 0.5rem !important;
        color: #1a1f36;
        margin-top: 10px;
    }
    .swal2-html-container {
        font-size: 0.9rem !important;
        margin: 0.3rem !important;
    }

    {{-- ── RTL Support (Arabic) ───────────────────────── --}}
    @if(app()->getLocale() === 'ar')
    body { direction: rtl; text-align: right; }
    .content-wrapper { margin-right: 200px !important; margin-left: 0 !important; }
    .main-sidebar { left: auto !important; right: 0 !important; border-right: none !important; border-left: 1px solid #e8eaf0 !important; }
    .navbar-nav { flex-direction: row-reverse; }
    .ml-1, .ml-2, .ml-3 { margin-left: 0 !important; margin-right: .25rem !important; }
    .mr-1, .mr-2, .mr-3 { margin-right: 0 !important; margin-left: .25rem !important; }
    @endif

    </style>
    @stack('css')
    @yield('css')
    @yield('extra_css')
@stop

@section('adminlte_js')
<script>
// ── Global Toast auto-hide ─────────────────────────────
setTimeout(function() {
    document.querySelectorAll('.toast').forEach(function(t) {
        $(t).fadeOut(500, function() { $(this).remove(); });
    });
}, 4000);

// ── Global SweetAlert Delete Confirm ──────────────────
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.swal-delete').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var form = this.closest('form');
            var msg  = this.getAttribute('data-message') || 'Are you sure?';
            Swal.fire({
                title: 'Are you sure?',
                text: msg,
                showCancelButton: true,
                confirmButtonColor: '#e74c3c',
                cancelButtonColor: '#95a5a6',
                confirmButtonText: 'Yes, Delete',
                cancelButtonText: 'Cancel',
                width: '350px',
                padding: '1rem',
            }).then(function(result) {
                if (result.isConfirmed) form.submit();
            });
        });
    });
});

// ── Unified Portal chrome helpers ─────────────────────
// Mobile sidebar backdrop (matches Client-Portal behaviour)
document.addEventListener('DOMContentLoaded', function() {
    var backdrop = document.createElement('div');
    backdrop.className = 'sidebar-backdrop';
    document.body.appendChild(backdrop);
    backdrop.addEventListener('click', function() {
        document.body.classList.remove('sidebar-open');
    });
});

// Auto-wrap plain tables so wide data never breaks the layout on mobile
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('table.table').forEach(function(t) {
        if (t.closest('.table-responsive') || t.closest('.dataTables_wrapper')) return;
        if (t.getAttribute('data-no-wrap') === '1') return;
        var wrap = document.createElement('div');
        wrap.className = 'table-responsive';
        t.parentNode.insertBefore(wrap, t);
        wrap.appendChild(t);
    });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    @stack('js')
    @yield('js')
    @yield('extra_js')
@stop
