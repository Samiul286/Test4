{{-- resources/views/layouts/super-admin.blade.php --}}
@extends('adminlte::page')
@section('title', 'Super Admin — ' . config('adminlte.title'))

{{-- ── Unified brand (topbar, left side) — Client-Portal design language ── --}}
@section('content_top_nav_left')
    <li class="nav-item">
        <a href="{{ route('super-admin.dashboard') }}" class="portal-brand">
            <span class="portal-logo-box">{{ strtoupper(substr(\App\Models\Setting::get('company_name', 'S'), 0, 1)) }}</span>
            <span class="portal-brand-name">{{ \App\Models\Setting::get('company_name', 'SmartISP') }}</span>
        </a>
    </li>
@endsection

{{-- ── Custom user menu (top-right) ──────────────────────────────
     AdminLTE's default user-menu reads Auth::user() (default 'web' guard),
     which is always null for Super Admin (separate 'super_admin' guard).
     This replaces that section entirely with the Client-Portal
     "user pill + dropdown" pattern, reading the correct guard. --}}
@section('content_top_nav_right')
    @php $saUser = Auth::guard('super_admin')->user(); @endphp
    <li class="nav-item dropdown user-menu">
        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
            <span>{{ $saUser->name ?? 'Super Admin' }}</span>
        </a>
        <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
            <li class="user-header" style="background:#f8f9fc; border-bottom:1px solid #f0f2f7; padding:16px;">
                <div style="display:flex; align-items:center; gap:12px;">
                    <div style="width:42px; height:42px; border-radius:50%; background:#1a1f36; color:#00c897;
                                display:flex; align-items:center; justify-content:center; font-size:16px; font-weight:700; flex-shrink:0;">
                        {{ strtoupper(substr($saUser->name ?? 'SA', 0, 2)) }}
                    </div>
                    <div>
                        <div style="font-size:14px; font-weight:600; color:#1a1f36;">{{ $saUser->name ?? 'Super Admin' }}</div>
                        <div style="font-size:12px; color:#888; margin-top:2px;">{{ $saUser->email ?? '' }}</div>
                    </div>
                </div>
            </li>
            <li class="user-footer">
                <form action="{{ route('super-admin.logout') }}" method="POST" style="display:flex; width:100%;">
                    @csrf
                    <button type="submit" class="btn btn-block text-left" style="color:#e74c3c;">
                        <i class="fas fa-sign-out-alt" style="color:#e74c3c;"></i> Logout
                    </button>
                </form>
            </li>
        </ul>
    </li>
@stop

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <h1 class="m-0">@yield('page_title')</h1>
        <div>@yield('page_actions')</div>
    </div>
@stop

{{-- Footer also carries the global flash toast (position:fixed). --}}
@section('footer')
    {{-- Global Toast Notification --}}
    @if(session('success') || session('error') || session('warning'))
    @php
        $type    = session('success') ? 'success' : (session('error') ? 'error' : 'warning');
        $message = session('success') ?? session('error') ?? session('warning');
        $color   = $type === 'success' ? '#00c897' : ($type === 'error' ? '#e74c3c' : '#f39c12');
        $icon    = $type === 'success' ? 'check-circle' : ($type === 'error' ? 'times-circle' : 'exclamation-triangle');
        $title   = $type === 'success' ? 'Success' : 'Error';
    @endphp
    <div style="position:fixed; top:76px; right:20px; z-index:9999; min-width:320px; max-width:calc(100vw - 40px);">
        <div class="toast show" role="alert"
             style="border:none; border-radius:8px; box-shadow:0 8px 30px rgba(0,0,0,0.18); overflow:hidden;">
            <div class="toast-header" style="background:{{ $color }}; color:#fff; border:none;">
                <i class="fas fa-{{ $icon }} mr-2"></i>
                <strong class="mr-auto">{{ $title }}</strong>
                <button type="button" class="ml-2 close" data-dismiss="toast" style="color:#fff; opacity:1;">&times;</button>
            </div>
            <div class="toast-body" style="background:#fff; font-size:13px; padding:12px 16px;">
                {{ $message }}
            </div>
        </div>
    </div>
    @endif

    {{ date('Y') }} &copy; {{ \App\Models\Setting::get('company_name', 'SmartISP') }} — Super Admin
@stop

@section('content')
    @yield('page_content')
@stop

@section('adminlte_css')
    <link rel="stylesheet" href="{{ asset('css/portal-theme.css') }}">
    <style>
    .swal2-title {
        font-size: 1.1rem !important;
        padding: 0.5rem !important;
        color: #1a1f36;
        margin-top: 10px;
    }
    .swal2-html-container {
        font-size: 0.9rem !important;
        margin: 0.3rem !important;
    }
    </style>
    @stack('css')
    @yield('css')
    @yield('extra_css')
@stop

@section('adminlte_js')
<script>
setTimeout(function() {
    document.querySelectorAll('.toast').forEach(function(t) {
        $(t).fadeOut(500, function() { $(this).remove(); });
    });
}, 4000);

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.swal-delete').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var form = this.closest('form');
            var msg  = this.getAttribute('data-message') || 'Are you sure?';
            Swal.fire({
                title: 'Are you sure?',
                text: msg,
                showCancelButton: true,
                confirmButtonColor: '#e74c3c',
                cancelButtonColor: '#95a5a6',
                confirmButtonText: 'Yes, Delete',
                cancelButtonText: 'Cancel',
            }).then(function(result) {
                if (result.isConfirmed) form.submit();
            });
        });
    });
});

// ── Unified Portal chrome helpers ─────────────────────
document.addEventListener('DOMContentLoaded', function() {
    var backdrop = document.createElement('div');
    backdrop.className = 'sidebar-backdrop';
    document.body.appendChild(backdrop);
    backdrop.addEventListener('click', function() {
        document.body.classList.remove('sidebar-open');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('table.table').forEach(function(t) {
        if (t.closest('.table-responsive') || t.closest('.dataTables_wrapper')) return;
        if (t.getAttribute('data-no-wrap') === '1') return;
        var wrap = document.createElement('div');
        wrap.className = 'table-responsive';
        t.parentNode.insertBefore(wrap, t);
        wrap.appendChild(t);
    });
});
</script>
    @stack('js')
    @yield('js')
    @yield('extra_js')
@stop
