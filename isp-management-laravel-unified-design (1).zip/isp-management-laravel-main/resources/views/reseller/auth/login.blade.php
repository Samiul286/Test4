{{-- resources/views/reseller/auth/login.blade.php --}}
@extends('layouts.auth')

@section('auth_title', 'Reseller Login')
@section('auth_subtitle', 'Reseller Portal')
@section('auth_icon', '<i class="fas fa-network-wired"></i>')

@section('auth_content')
    <form method="POST" action="{{ route('reseller.login.submit') }}">
        @csrf

        <div class="form-group">
            <label for="username">{{ __('Username') }}</label>
            <div class="input-wrap">
                <i class="fas fa-user"></i>
                <input type="text" id="username" name="username"
                    class="form-control {{ $errors->has('username') ? 'is-invalid' : '' }}"
                    placeholder="{{ __('Your reseller username') }}"
                    value="{{ old('username') }}" required autofocus autocomplete="username">
            </div>
            @error('username')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="password">{{ __('Password') }}</label>
            <div class="input-wrap">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="{{ __('Your password') }}"
                    required autocomplete="current-password">
            </div>
            @error('password')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="remember-row">
            <input type="checkbox" name="remember" id="remember" value="1">
            <label for="remember">{{ __('Remember me') }}</label>
        </div>

        <button type="submit" class="btn-login">
            <i class="fas fa-sign-in-alt" style="margin-right:6px;"></i> {{ __('Sign In') }}
        </button>
    </form>
@endsection

@section('auth_note')
    <div class="hint-box">
        <strong><i class="fas fa-info-circle"></i> {{ __('Login Info') }}</strong>
        {{ __('Use the credentials provided by your ISP administrator to manage your clients.') }}
    </div>
@endsection
