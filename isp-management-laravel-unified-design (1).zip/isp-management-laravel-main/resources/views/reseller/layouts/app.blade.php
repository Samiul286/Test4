{{-- resources/views/reseller/layouts/app.blade.php --}}
{{-- Reseller Portal chrome — unified Client Self-Service Portal design system.
     All menu/permission logic preserved (allowed_menus, staff restrictions). --}}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Dashboard') — {{ auth('mac_reseller')->user()->business_name ?? 'Reseller Portal' }}</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    {{-- Unified Portal Design System (Client Self-Service Portal master design) --}}
    <link rel="stylesheet" href="{{ asset('css/portal-theme.css') }}">

    <style>
        * { box-sizing: border-box; }
        body { background: #f4f6f9; font-family: 'Segoe UI', Tahoma, -apple-system, sans-serif; }

        /* ── Topbar (Client-Portal design) ─────────────── */
        .portal-topbar {
            background: #1a1f36;
            color: #fff;
            height: 56px;
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 20px;
            position: fixed; top: 0; left: 0; right: 0; z-index: 200;
            box-shadow: 0 1px 4px rgba(26,31,54,.18);
        }
        .topbar-left { display: flex; align-items: center; gap: 12px; min-width: 0; }
        .hamburger {
            background: none; border: none; color: #fff; font-size: 20px;
            cursor: pointer; display: none; padding: 4px 8px; margin-left: -8px;
        }
        .topbar-brand {
            display: flex; align-items: center; gap: 10px;
            font-size: 18px; font-weight: 700; color: #fff; text-decoration: none;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 260px;
        }
        .topbar-brand .logo-box {
            width: 36px; height: 36px; background: #00c897;
            border-radius: 8px; display: flex; align-items: center; justify-content: center;
            font-size: 16px; font-weight: 800; color: #fff; flex-shrink: 0;
        }
        .topbar-right { display: flex; align-items: center; gap: 12px; }

        /* User pill (Client-Portal design) */
        .user-pill {
            display: flex; align-items: center; gap: 8px;
            background: rgba(255,255,255,.1); border-radius: 999px;
            padding: 5px 14px 5px 5px; cursor: pointer;
            border: none; position: relative;
        }
        .user-pill::after { display: none; }
        .user-pill .user-avatar {
            width: 30px; height: 30px; background: #00c897;
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-size: 12px; font-weight: 700; color: #fff; flex-shrink: 0;
        }
        .user-pill .user-name { font-size: 13px; color: #fff; white-space: nowrap; }
        .user-pill .chev { font-size: 10px; color: rgba(255,255,255,.6); }
        .user-pill:hover { background: rgba(255,255,255,.18); }
        .user-pill.show { background: rgba(255,255,255,.18); }

        /* ── Sidebar (Client-Portal design) ────────────── */
        .portal-sidebar {
            width: 200px; background: #fff; border-right: 1px solid #e8eaf0;
            position: fixed; top: 56px; left: 0; bottom: 0;
            overflow-y: auto; overflow-x: hidden; z-index: 100;
            transition: transform .25s;
        }
        .sidebar-nav { padding: 12px 0 24px; }

        .nav-link, .nav-toggle {
            display: flex; align-items: center; gap: 10px;
            padding: 11px 20px; font-size: 13.5px; color: #555;
            text-decoration: none !important; border-left: 3px solid transparent;
            transition: all .15s; cursor: pointer; background: transparent;
            border-top: none; border-right: none; border-bottom: none;
            width: 100%; text-align: left; border-radius: 0;
        }
        .nav-link i, .nav-toggle i { width: 18px; text-align: center; font-size: 15px; color: #aaa; }
        .nav-link:hover, .nav-toggle:hover {
            background: #f0faf7; color: #00c897; text-decoration: none !important;
        }
        .nav-link:hover i, .nav-toggle:hover i { color: #00c897; }
        .nav-link.active {
            background: #f0faf7; color: #00c897; border-left-color: #00c897; font-weight: 600;
        }
        .nav-link.active i { color: #00c897; }
        .nav-toggle { justify-content: space-between; }
        .nav-toggle .nav-toggle-left { display: flex; align-items: center; gap: 10px; min-width: 0; }
        .nav-toggle .nav-toggle-left i { margin-right: 0; }
        .nav-toggle i.chevron { width: auto; font-size: .7rem; transition: transform .2s; color: #aab; }
        .nav-toggle[aria-expanded="true"] i.chevron { transform: rotate(90deg); }
        .nav-toggle[aria-expanded="true"] { color: #1a1f36; font-weight: 600; }
        .nav-toggle[aria-expanded="true"] i { color: #1a1f36; }

        .submenu { background: #f8f9fc; }
        .submenu .nav-link { padding: 9px 20px 9px 48px; font-size: 13px; color: #777; }
        .submenu .nav-link:hover { color: #00c897; }
        .submenu .nav-link.active { color: #00c897; }

        /* ── Content (Client-Portal design) ────────────── */
        .portal-content { margin-left: 200px; min-height: calc(100vh - 56px); padding: 24px 24px 0; margin-top: 56px; }
        .page-title { font-size: 22px; font-weight: 600; color: #1a1f36; margin-bottom: 20px; }

        /* ── Footer (Client-Portal design) ─────────────── */
        .portal-footer {
            text-align: center; padding: 16px; font-size: 12px; color: #aaa;
            border-top: 1px solid #eef0f5; background: #fff; margin: 24px -24px 0;
        }

        /* ── Backdrop (mobile) ──────────────────────────── */
        .sidebar-backdrop {
            display: none; position: fixed; inset: 0;
            background: rgba(26,31,54,.45); z-index: 150;
        }
        body.sidebar-open .sidebar-backdrop { display: block; }

        /* ── User dropdown menu (Client-Portal design) ──── */
        .user-pill .dropdown-menu {
            border-radius: 12px; border: 1px solid #eef0f5;
            box-shadow: 0 8px 30px rgba(0,0,0,.15); padding: 0; min-width: 230px; margin-top: 10px;
        }
        .user-dd-header { display: flex; align-items: center; gap: 12px; padding: 16px; background: #f8f9fc; border-bottom: 1px solid #f0f2f7; }
        .user-dd-avatar {
            width: 42px; height: 42px; background: #1a1f36; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px; font-weight: 700; color: #00c897; flex-shrink: 0;
        }
        .user-dd-name { font-size: 14px; font-weight: 600; color: #1a1f36; }
        .user-dd-sub { font-size: 12px; color: #888; margin-top: 2px; }
        .user-pill .dropdown-item { font-size: 13px; }

        @media (max-width: 768px) {
            .hamburger { display: block; }
            .portal-sidebar { transform: translateX(-100%); box-shadow: 12px 0 30px rgba(26,31,54,.12); }
            .portal-sidebar.show { transform: translateX(0); }
            .portal-content { margin-left: 0; padding: 16px 16px 0; }
            .portal-footer { margin: 16px -16px 0; }
            .user-pill .user-name { display: none; }
            .user-pill { padding: 5px; }
            .topbar-brand { max-width: 170px; }
            .form-row { grid-template-columns: 1fr; }
        }
    </style>
    @yield('css')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
</head>
<body>

    {{-- ── Topbar ─────────────────────────────────────────────────────────── --}}
    <div class="portal-topbar">
        <div class="topbar-left">
            <button class="hamburger" onclick="toggleSidebar()" aria-label="Toggle menu">
                <i class="fas fa-bars"></i>
            </button>
            <a href="{{ route('reseller.dashboard') }}" class="topbar-brand">
                <span class="logo-box">{{ strtoupper(substr(auth('mac_reseller')->user()->business_name ?? 'R', 0, 1)) }}</span>
                <span>{{ auth('mac_reseller')->user()->business_name ?? 'Reseller Panel' }}</span>
            </a>
        </div>
        <div class="topbar-right">
            @if(session('impersonator_admin_id'))
                <a href="{{ route('reseller.back-to-admin') }}" class="btn btn-sm" style="background:#f39c12; color:#fff; border:none;">
                    <i class="fas fa-arrow-left mr-1"></i> Back to Admin
                </a>
            @endif

            <div class="dropdown">
                <button class="user-pill dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="user-avatar">{{ strtoupper(substr(auth('mac_reseller')->user()->contact_person ?? auth('mac_reseller')->user()->business_name ?? 'R', 0, 2)) }}</span>
                    <span class="user-name">{{ auth('mac_reseller')->user()->contact_person ?? 'Reseller' }}</span>
                    <i class="fas fa-chevron-down chev"></i>
                </button>
                <div class="dropdown-menu dropdown-menu-right">
                    <div class="user-dd-header">
                        <div class="user-dd-avatar">{{ strtoupper(substr(auth('mac_reseller')->user()->contact_person ?? auth('mac_reseller')->user()->business_name ?? 'R', 0, 2)) }}</div>
                        <div>
                            <div class="user-dd-name">{{ auth('mac_reseller')->user()->contact_person ?? 'Reseller' }}</div>
                            <div class="user-dd-sub">{{ auth('mac_reseller')->user()->business_name ?? '' }}</div>
                        </div>
                    </div>
                    <a href="{{ route('reseller.configuration.index') }}" class="dropdown-item">
                        <i class="fas fa-user-cog"></i> Account Settings
                    </a>
                    <div class="dropdown-divider"></div>
                    @if(session('impersonator_admin_id'))
                        <a href="{{ route('reseller.back-to-admin') }}" class="dropdown-item">
                            <i class="fas fa-arrow-left"></i> Back to Admin
                        </a>
                        <div class="dropdown-divider"></div>
                    @endif
                    <form action="{{ route('reseller.logout') }}" method="POST">
                        @csrf
                        <button type="submit" class="dropdown-item text-danger">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    {{-- ── Sidebar ────────────────────────────────────────────────────────── --}}
    <div class="sidebar-backdrop" onclick="toggleSidebar()"></div>
    <div class="portal-sidebar" id="resellerSidebar">
        <nav class="sidebar-nav">
            <a class="nav-link {{ request()->routeIs('reseller.dashboard') ? 'active' : '' }}" href="{{ route('reseller.dashboard') }}">
                <i class="fas fa-th-large"></i> Dashboard
            </a>

            @php
                // Every item is rendered as an accordion (chevron + collapsible submenu),
                // matching the reference sidebar's look. Each currently has one child
                // (its existing index page) — add more entries to 'children' later
                // as soon as a menu gets additional sub-pages/routes.
                $menuLinks = [
                    'CONFIGURATION' => [
                        'icon' => 'fa-sliders-h', 'label' => 'Configuration',
                        'children' => [
                            ['route' => 'reseller.configuration.zone.index',    'icon' => 'fa-map-marker-alt', 'label' => 'Zone'],
                            ['route' => 'reseller.configuration.subzone.index', 'icon' => 'fa-map-pin',        'label' => 'Sub Zone'],
                            ['route' => 'reseller.configuration.box.index',         'icon' => 'fa-box',           'label' => 'Box'],
                            ['route' => 'reseller.configuration.package.index',     'icon' => 'fa-boxes',         'label' => 'Package'],
                        ],
                    ],
                    'MIKROTIK CLIENT' => [
                        'icon' => 'fa-server', 'label' => 'Mikrotik Client',
                        'children' => [
                            ['route' => 'reseller.mikrotik-client.index',       'icon' => 'fa-list',          'label' => 'Mikrotik Clients'],
                            ['route' => 'reseller.mikrotik-client.bulk-import', 'icon' => 'fa-file-import',   'label' => 'Bulk Clients Import'],
                        ],
                    ],
                    'EMPLOYEES' => [
                        'icon' => 'fa-user-shield', 'label' => 'Staff Login',
                        'children' => [
                            ['route' => 'reseller.employees.index',  'icon' => 'fa-list',      'label' => 'Staff List'],
                        ],
                    ],
                    'CLIENT' => [
                        'icon' => 'fa-user', 'label' => 'Client',
                        'children' => [
                            ['route' => 'reseller.client.create',         'icon' => 'fa-user-plus',    'label' => 'Add Client'],
                            ['route' => 'reseller.client.index',          'icon' => 'fa-list',         'label' => 'Client List'],
                        ],
                    ],
                    'BILLING' => [
                        'icon' => 'fa-file-invoice-dollar', 'label' => 'Billing',
                        'children' => [
                            ['route' => 'reseller.billing.index',   'icon' => 'fa-list',          'label' => 'Billing List'],
                            ['route' => 'reseller.billing.create',  'icon' => 'fa-file-invoice',  'label' => 'Create Invoice'],
                            ['route' => 'reseller.payment.collect', 'icon' => 'fa-hand-holding-usd','label' => 'Collect Payment'],
                            ['route' => 'reseller.payment.index',   'icon' => 'fa-history',       'label' => 'Payment History'],
                        ],
                    ],
                    'MONITORING' => [
                        'icon' => 'fa-chart-line', 'label' => 'Monitoring',
                        'children' => [
                            ['route' => 'reseller.monitoring.index', 'icon' => 'fa-desktop', 'label' => 'Client Monitoring'],
                        ],
                    ],
                    'CLIENT SUPPORT' => [
                        'icon' => 'fa-headset', 'label' => 'Support & Ticketing',
                        'children' => [
                            ['route' => 'reseller.client-support.category.index', 'icon' => 'fa-tag',      'label' => 'Support Category'],
                            ['route' => 'reseller.client-support.index',    'icon' => 'fa-tablet-alt', 'label' => 'Client Support'],
                            ['route' => 'reseller.client-support.monthly',  'icon' => 'fa-redo',      'label' => 'Support History'],
                        ],
                    ],
                    'SMS SERVICE' => [
                        'icon' => 'fa-sms', 'label' => 'SMS Service',
                        'children' => [
                            ['route' => 'reseller.sms-service.settings.index',  'icon' => 'fa-server',      'label' => 'Gateway Settings'],
                            ['route' => 'reseller.sms-service.templates.index', 'icon' => 'fa-file-alt',    'label' => 'Templates'],
                            ['route' => 'reseller.sms-service.send',           'icon' => 'fa-paper-plane', 'label' => 'Send SMS'],
                            ['route' => 'reseller.sms-service.reports',        'icon' => 'fa-chart-bar',   'label' => 'SMS Reports'],
                        ],
                    ],
                    'REPORT' => [
                        'icon' => 'fa-chart-bar', 'label' => 'Report',
                        'children' => [
                            ['route' => 'reseller.report.btrc',            'icon' => 'fa-file-alt',   'label' => 'BTRC Report'],
                            ['route' => 'reseller.report.status-history',  'icon' => 'fa-history',    'label' => 'Enable/Disable History'],
                            ['route' => 'reseller.report.bill-collection', 'icon' => 'fa-hand-holding-usd', 'label' => 'Bill Collection'],
                            ['route' => 'reseller.report.messages',        'icon' => 'fa-comment-dots','label' => 'Messages Report'],
                            ['route' => 'reseller.report.index',           'icon' => 'fa-list',       'label' => 'All Report'],
                        ],
                    ],
                    'FUND HISTORY' => [
                        'icon' => 'fa-wallet', 'label' => 'Fund History',
                        'children' => [
                            ['route' => 'reseller.fund-history.debit',  'icon' => 'fa-arrow-down', 'label' => 'Debit History'],
                            ['route' => 'reseller.fund-history.credit', 'icon' => 'fa-arrow-up',   'label' => 'Credit History'],
                        ],
                    ],
                    'TUTORIALS' => [
                        'icon' => 'fa-book', 'label' => 'Tutorials',
                        'children' => [
                            ['route' => 'reseller.tutorials.index', 'icon' => 'fa-video', 'label' => 'All Tutorials'],
                        ],
                    ],
                ];
                $allowedUpper = [];
                $isStaffSession = session('reseller_employee_id');

                if ($isStaffSession) {
                    // logged in as a staff (sub-employee) — use THEIR OWN allowed_menus,
                    // not the reseller owner's
                    $staffEmployee = \App\Models\ResellerEmployee::find($isStaffSession);
                    $allowed = $staffEmployee->allowed_menus ?? [];
                } else {
                    // logged in as the reseller owner — use the owner's allowed_menus
                    // (set by ISP Admin for this reseller/POP)
                    $allowed = auth('mac_reseller')->user()->allowed_menus ?? [];
                }

                $allowedUpper = array_map('strtoupper', $allowed);

                // split so HR & Payroll can be rendered between Client Support and SMS Service
                $menuLinksTop    = array_slice($menuLinks, 0, 7, true);  // CONFIGURATION .. CLIENT SUPPORT
                $menuLinksBottom = array_slice($menuLinks, 7, null, true); // SMS SERVICE .. TUTORIALS
            @endphp

            @foreach($menuLinksTop as $key => $item)
                @if(in_array($key, $allowedUpper))

                    @if(!empty($item['children']))
                        @php
                            $isParentActive = collect($item['children'])->contains(function ($child) {
                                return request()->routeIs(str_replace('.index', '.*', $child['route']))
                                    || request()->routeIs($child['route'] . '*');
                            });
                            $collapseId = 'submenu-' . \Illuminate\Support\Str::slug($key);
                        @endphp
                        <a href="#" class="nav-toggle {{ $isParentActive ? 'active' : '' }}"
                           data-toggle="collapse" data-target="#{{ $collapseId }}"
                           aria-expanded="{{ $isParentActive ? 'true' : 'false' }}">
                            <span class="nav-toggle-left">
                                <i class="fas {{ $item['icon'] }}"></i> {{ $item['label'] }}
                            </span>
                            <i class="fas fa-chevron-right chevron"></i>
                        </a>
                        <div class="collapse submenu {{ $isParentActive ? 'show' : '' }}" id="{{ $collapseId }}">
                            @foreach($item['children'] as $child)
                                <a class="nav-link {{ request()->routeIs(str_replace('.index', '.*', $child['route'])) || request()->routeIs($child['route'] . '*') ? 'active' : '' }}"
                                   href="{{ route($child['route']) }}">
                                    <i class="fas {{ $child['icon'] }}"></i> {{ $child['label'] }}
                                </a>
                            @endforeach
                        </div>
                    @else
                        <a class="nav-link {{ request()->routeIs(str_replace('.index', '.*', $item['route'])) ? 'active' : '' }}" href="{{ route($item['route']) }}">
                            <i class="fas {{ $item['icon'] }}"></i> {{ $item['label'] }}
                        </a>
                    @endif

                @endif
            @endforeach

            @unless($isStaffSession)
            {{-- HR & Payroll — owner only, never assignable to staff — placed before SMS Service --}}
            <a href="#" class="nav-toggle {{ request()->routeIs('reseller.hr.*') ? 'active' : '' }}"
               data-toggle="collapse" data-target="#hrPayrollSubmenu"
               aria-expanded="{{ request()->routeIs('reseller.hr.*') ? 'true' : 'false' }}">
                <span class="nav-toggle-left"><i class="fas fa-user-tie"></i> HR & Payroll</span>
                <i class="fas fa-chevron-right chevron"></i>
            </a>
            <div class="collapse submenu {{ request()->routeIs('reseller.hr.*') ? 'show' : '' }}" id="hrPayrollSubmenu">
                <a class="nav-link {{ request()->routeIs('reseller.hr.department.*') ? 'active' : '' }}" href="{{ route('reseller.hr.department.index') }}">
                    <i class="fas fa-building"></i> Departments
                </a>
                <a class="nav-link {{ request()->routeIs('reseller.hr.position.*') ? 'active' : '' }}" href="{{ route('reseller.hr.position.index') }}">
                    <i class="fas fa-briefcase"></i> Positions
                </a>
                <a class="nav-link {{ request()->routeIs('reseller.hr.salary-head.*') ? 'active' : '' }}" href="{{ route('reseller.hr.salary-head.index') }}">
                    <i class="fas fa-list"></i> Salary Heads
                </a>
                <a class="nav-link {{ request()->routeIs('reseller.hr.employee.index') ? 'active' : '' }}" href="{{ route('reseller.hr.employee.index') }}">
                    <i class="fas fa-users"></i> Employee List
                </a>
                <a class="nav-link {{ request()->routeIs('reseller.hr.employee.create') ? 'active' : '' }}" href="{{ route('reseller.hr.employee.create') }}">
                    <i class="fas fa-user-plus"></i> Add Employee
                </a>
                <a class="nav-link {{ request()->routeIs('reseller.hr.payroll.index') ? 'active' : '' }}" href="{{ route('reseller.hr.payroll.index') }}">
                    <i class="fas fa-money-check-alt"></i> Payroll
                </a>
                <a class="nav-link {{ request()->routeIs('reseller.hr.payroll.create') ? 'active' : '' }}" href="{{ route('reseller.hr.payroll.create') }}">
                    <i class="fas fa-plus-circle"></i> Generate Payroll
                </a>
                <a class="nav-link {{ request()->routeIs('reseller.hr.salary-advance.*') ? 'active' : '' }}" href="{{ route('reseller.hr.salary-advance.index') }}">
                    <i class="fas fa-hand-holding-usd"></i> Salary Advance
                </a>
                <a class="nav-link {{ request()->routeIs('reseller.hr.leave-type.*') ? 'active' : '' }}" href="{{ route('reseller.hr.leave-type.index') }}">
                    <i class="fas fa-calendar-alt"></i> Leave Types
                </a>
                <a class="nav-link {{ request()->routeIs('reseller.hr.leave-application.*') ? 'active' : '' }}" href="{{ route('reseller.hr.leave-application.index') }}">
                    <i class="fas fa-calendar-check"></i> Leave Applications
                </a>
            </div>
            @endunless

            @foreach($menuLinksBottom as $key => $item)
                @if(in_array($key, $allowedUpper))

                    @if(!empty($item['children']))
                        @php
                            $isParentActive = collect($item['children'])->contains(function ($child) {
                                return request()->routeIs(str_replace('.index', '.*', $child['route']))
                                    || request()->routeIs($child['route'] . '*');
                            });
                            $collapseId = 'submenu-' . \Illuminate\Support\Str::slug($key);
                        @endphp
                        <a href="#" class="nav-toggle {{ $isParentActive ? 'active' : '' }}"
                           data-toggle="collapse" data-target="#{{ $collapseId }}"
                           aria-expanded="{{ $isParentActive ? 'true' : 'false' }}">
                            <span class="nav-toggle-left">
                                <i class="fas {{ $item['icon'] }}"></i> {{ $item['label'] }}
                            </span>
                            <i class="fas fa-chevron-right chevron"></i>
                        </a>
                        <div class="collapse submenu {{ $isParentActive ? 'show' : '' }}" id="{{ $collapseId }}">
                            @foreach($item['children'] as $child)
                                <a class="nav-link {{ request()->routeIs(str_replace('.index', '.*', $child['route'])) || request()->routeIs($child['route'] . '*') ? 'active' : '' }}"
                                   href="{{ route($child['route']) }}">
                                    <i class="fas {{ $child['icon'] }}"></i> {{ $child['label'] }}
                                </a>
                            @endforeach
                        </div>
                    @else
                        <a class="nav-link {{ request()->routeIs(str_replace('.index', '.*', $item['route'])) ? 'active' : '' }}" href="{{ route($item['route']) }}">
                            <i class="fas {{ $item['icon'] }}"></i> {{ $item['label'] }}
                        </a>
                    @endif

                @endif
            @endforeach

            @unless($isStaffSession)
            {{-- Settings — owner only, never assignable to staff --}}
            <a class="nav-link {{ request()->routeIs('reseller.settings.*') ? 'active' : '' }}" href="{{ route('reseller.settings.index') }}">
                <i class="fas fa-cog"></i> Settings
            </a>
            @endunless
        </nav>
    </div>

    {{-- ── Main Content ───────────────────────────────────────────────────── --}}
    <div class="portal-content">
        @hasSection('title')
            <div class="page-title">@yield('title')</div>
        @endif

        @if(session('success'))
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span>{{ session('success') }}</span>
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <span>{{ session('error') }}</span>
            </div>
        @endif
        @if(session('warning'))
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i>
                <span>{{ session('warning') }}</span>
            </div>
        @endif

        @yield('content')

        <footer class="portal-footer">
            {{ date('Y') }} &copy; {{ auth('mac_reseller')->user()->business_name ?? 'Reseller Portal' }}
        </footer>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script>
    function toggleSidebar() {
        var sb = document.getElementById('resellerSidebar');
        sb.classList.toggle('show');
        document.body.classList.toggle('sidebar-open');
    }

    // Auto-wrap plain tables so wide data never breaks the layout on mobile
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('table.table').forEach(function(t) {
            if (t.closest('.table-responsive') || t.closest('.dataTables_wrapper')) return;
            if (t.getAttribute('data-no-wrap') === '1') return;
            var wrap = document.createElement('div');
            wrap.className = 'table-responsive';
            t.parentNode.insertBefore(wrap, t);
            wrap.appendChild(t);
        });
    });

    // Close the mobile sidebar when navigating (feels native, like the client portal)
    document.addEventListener('click', function(e) {
        var sb = document.getElementById('resellerSidebar');
        if (!sb) return;
        var link = e.target.closest('.portal-sidebar a[href]');
        if (link && window.innerWidth <= 768) {
            sb.classList.remove('show');
            document.body.classList.remove('sidebar-open');
        }
    });
    </script>
    @yield('js')
</body>
</html>
